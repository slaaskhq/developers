<?php   
class Sysnak_Addscript_Block_Index extends Mage_Core_Block_Template{   





}