package com.slaask.lib.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.slaask.lib.R;
import com.slaask.lib.controller.SLAASKManager;
import com.slaask.lib.controller.clients.ChromeClient;
import com.slaask.lib.controller.clients.WebClient;

public class SLAASKFragment extends Fragment {

	public static final String TAG = "SLAASKFragment";
	private  SLAASKWebView webView;
	private String completeCode;
	private SLAASKManager slaaskManager;
	private LinearLayout myLayout;
	private ChromeClient client;

	public void setSLAASKView(String completeCode, SLAASKManager slaaskManager) {
		this.completeCode = completeCode;
		this.slaaskManager = slaaskManager;
	}

	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
	}

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.layput_web_view, container, false);
		myLayout = (LinearLayout) view.findViewById(R.id.linear_layout);
		return view;
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		webView = new SLAASKWebView(slaaskManager.getActivity());
		webView.setLayoutParams(new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT));
		myLayout.addView(webView);
		client = new ChromeClient(slaaskManager);
		webView.open( new WebClient(slaaskManager), client , completeCode);
	}

	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		savedInstanceState.putString("saved","true");
		super.onSaveInstanceState(savedInstanceState);

	}

	public SLAASKWebView getWebView() {
		return webView;
	}

	public ChromeClient getChromeClient() {
		return client;
	}
}
