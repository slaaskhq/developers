package com.slaask.lib.controller;

class ScriptProvider {

	static String getScript(String codeString, String visitorToken, String identify) {

		codeString = codeString.replace("<style class=\"embedly-css\">", "<style class=\"embedly-css\"> #slaask-widget { width: 100%; right: 0}");
		codeString = codeString.replace("id=\"slaask-widget-footer\"",
				"id=\"slaask-widget-footer\" style=\"max-width: 100%\"");
		codeString = codeString.replace("_slaask.hide({ by: 'cross_click' })\n" +
						"      titleChangingStop()",
				"_slaask.hide({by:\"cross_click\"}),window.location.href = \"slaask://closeButtonPressed\";");

		return "<!DOCTYPE html><html>"
				+ "<head></head>"
				+ "<style>.slaask-button { display: none !important; }</style>"
				+ "<script>" + codeString + "</script>"
				+ "<script type=\"text/javascript\"> "
				+ "document.addEventListener(\"DOMContentLoaded\", function (event) {"
				+ " window._slaask.init(\'" + visitorToken+ "\',  { visitor_token:\"" + visitorToken+ "\"}),"
				+ "document.addEventListener(\'slaask.ready\', function()  {"
				+ "window._slaask.show({ by: \"button_click\" });" +
				"}, false);});"
				+ "</script>"
				+ "<body></body></html>";
	}
}
