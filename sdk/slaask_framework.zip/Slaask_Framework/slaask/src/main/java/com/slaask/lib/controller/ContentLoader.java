package com.slaask.lib.controller;

import android.os.AsyncTask;
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

 class ContentLoader  extends AsyncTask<String, String, String> {
	private ILoadCompletion loadCompletion;

	ContentLoader(ILoadCompletion loadCompletion) {
		this.loadCompletion = loadCompletion;
	}

	@Override
	protected String doInBackground(String... strings) {

		StringBuilder stringBuilder = new StringBuilder();
		try {
			Scanner scanner = new Scanner(new URL(strings[0]).openStream(), "UTF-8").useDelimiter("\\A");
			while (scanner.hasNextLine()) {
				stringBuilder.append(scanner.nextLine());
				stringBuilder.append("\n");
			}
			return stringBuilder.toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return stringBuilder.toString();
	}

	@Override
	protected void onPostExecute(String jsString) {
		super.onPostExecute(jsString);

		if (loadCompletion != null) {
			loadCompletion.onLoadComplete(jsString);
		}
	}

	interface ILoadCompletion {
		void onLoadComplete(String loadedString);
	}
}