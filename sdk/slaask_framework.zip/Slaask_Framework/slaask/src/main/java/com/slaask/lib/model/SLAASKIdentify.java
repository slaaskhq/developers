package com.slaask.lib.model;

import java.util.HashMap;

public class SLAASKIdentify {

	private final String identifyName;
	private HashMap<String, String> options;

	public SLAASKIdentify(String identifyName) {
		this.identifyName = identifyName;
	}

	public  SLAASKIdentify(String identifyName,  HashMap<String, String> options) {
		this(identifyName);
		this.options = options;
	}

	public String getIdentifyName() {
		return identifyName;
	}

	public HashMap<String, String> getOptions() {
		return options;
	}

	public void setOptions(HashMap<String, String> options) {
		this.options = options;
	}
}
