package com.slaask.lib.view;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.webkit.CookieManager;
import android.webkit.WebView;
import com.slaask.lib.controller.clients.ChromeClient;
import com.slaask.lib.controller.clients.WebClient;
import static com.slaask.lib.model.Constants.ENCODING;
import static com.slaask.lib.model.Constants.MIME_TYPE;

public class SLAASKWebView extends WebView {

	public SLAASKWebView(Activity activity) {
		super(activity.getApplicationContext());
	}

	public SLAASKWebView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public void open(WebClient webClient, ChromeClient chromeClient, String completeCode) {
		getSettings().setJavaScriptEnabled(true);
		getSettings().setDomStorageEnabled(true);
		getSettings().setAllowFileAccess(true);
		CookieManager.getInstance().setAcceptCookie(true);
		setWebViewClient(webClient);
		setWebChromeClient(chromeClient);
		loadDataWithBaseURL("https://slaask.com", completeCode, MIME_TYPE, ENCODING, null);
	}
}
