package com.slaask.lib.model;

public class Constants {
	public static final String JS_URL = "https://cdn.slaask.com/chat_native.js";
	public static final int INPUT_FILE_REQUEST_CODE = 12345;
	public static final String MIME_TYPE = "text/html";
	public static final String ENCODING = "UTF-8";
}
