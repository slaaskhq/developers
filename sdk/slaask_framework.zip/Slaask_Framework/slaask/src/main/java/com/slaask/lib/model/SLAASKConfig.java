package com.slaask.lib.model;

public class SLAASKConfig {

    private  SLAASKIdentify  identify;
    private   String visitorToken = "";
    private  final String token;

    public SLAASKConfig( String  token){
        this.token = token;
    }

    public SLAASKConfig( String  token , SLAASKIdentify  identify){
        this(token);
        this.identify = identify;
    }

    public SLAASKIdentify getIdentify() {
        return identify;
    }

    public void setIdentify(SLAASKIdentify identify) {
        this.identify = identify;
    }

    public String getVisitorToken() {
        return visitorToken;
    }

    public void setVisitorToken(String visitorToken) {
        this.visitorToken = visitorToken;
    }

    public String getToken() {
        return token;
    }
}
