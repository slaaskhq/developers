package com.slaask.lib.controller;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import com.slaask.lib.model.SLAASKConfig;
import com.slaask.lib.view.SLAASKFragment;
import static com.slaask.lib.model.Constants.JS_URL;

public class SLAASKManager implements ContentLoader.ILoadCompletion {

	private final String TAG = getClass().getSimpleName();
	private static volatile SLAASKManager instance;
	private SLAASKFragment slaaskFragment;
	private SLAASKConfig mConfig;
	private int containerId;
	private Activity activity;
	private String mCompleteCode = "";

	public void show() {
		if (mConfig.getVisitorToken() == null) {
			Log.e(TAG,"visitor token = null not aloud");
		} else {
			Log.d(TAG, "SLAASK load js");
			if(!mCompleteCode.isEmpty()) {
				openFragment(mCompleteCode);
			} else {
				new ContentLoader(this).execute(JS_URL);
			}

		}
	}

	public void dismiss() {
		if (slaaskFragment != null) {
			Log.d(TAG, "SLAASK dismissed");
			slaaskFragment.getFragmentManager().popBackStack();
		}
	}

	public void reload() {
		if (slaaskFragment !=null) {
			Log.d(TAG, "SLAASK reload");
			slaaskFragment.getWebView().reload();
		}
	}

	@Override
	public void onLoadComplete(String loadedString) {
		mCompleteCode = ScriptProvider.getScript(loadedString, mConfig.getToken(), mConfig.getVisitorToken());
		openFragment(mCompleteCode);
	}

	private void openFragment(String completeCode) {
		if (activity.getIntent().getStringExtra("saved") == null) {
			slaaskFragment = new SLAASKFragment();
			slaaskFragment.setSLAASKView(completeCode, this);
			slaaskFragment.setArguments(activity.getIntent().getExtras());
			((AppCompatActivity) activity).getSupportFragmentManager()
					.beginTransaction()
					.add(android.R.id.content, slaaskFragment, "SLAASKFragment")
					.addToBackStack(null)
					.commit();
		} else {
			slaaskFragment = (SLAASKFragment) ((AppCompatActivity) activity).getSupportFragmentManager().findFragmentByTag("SLAASKFragment");
			slaaskFragment.setSLAASKView(completeCode, this);
			FragmentManager fragmentManager = ((AppCompatActivity) activity).getSupportFragmentManager();
			fragmentManager
					.beginTransaction()
					.replace(containerId, slaaskFragment)
					.addToBackStack(null)
					.commit();
		}
	}



	public SLAASKManager setConfig(SLAASKConfig config) {
		mConfig = config;
		return this;
	}

	public static SLAASKManager getInstance() {
		SLAASKManager localInstance = instance;
		if (localInstance == null) {
			synchronized (SLAASKManager.class) {
				localInstance = instance;
				if (localInstance == null) {
					instance = localInstance = new SLAASKManager();
				}
			}
		}
		return localInstance;
	}

	private  SLAASKManager(){

	}

	public void onBrowserIntent(Intent browserIntent) {
		activity.startActivity(browserIntent);
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		slaaskFragment.getChromeClient().onActivityResult(requestCode, resultCode, data);
	}

	public SLAASKManager setContainerId(int containerId) {
		this.containerId = containerId;
		return this;
	}

	public SLAASKManager setContainerActivity(Activity activity) {
		this.activity = activity;
		return this;
	}

	public Activity getActivity() {
		return activity;
	}
}