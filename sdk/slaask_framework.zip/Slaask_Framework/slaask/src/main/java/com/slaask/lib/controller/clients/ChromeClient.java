package com.slaask.lib.controller.clients;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import com.slaask.lib.controller.SLAASKManager;

import java.io.File;
import static android.app.Activity.RESULT_OK;
import static com.slaask.lib.model.Constants.INPUT_FILE_REQUEST_CODE;

public class ChromeClient extends WebChromeClient {
	private SLAASKManager slaaskManager;
	private ValueCallback<Uri[]> mFilePathCallback;
	private ValueCallback<Uri> mUploadMessage;
	private String mCameraPhotoPath;
	private Uri mCapturedImageURI;

	public ChromeClient(SLAASKManager slaaskManager) {
		this.slaaskManager = slaaskManager;
	}

	@Override
	public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {

		if (mFilePathCallback != null) {
			mFilePathCallback.onReceiveValue(null);
		}
		mFilePathCallback = filePathCallback;

		File imageStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "TestApp");
		if (!imageStorageDir.exists()) {
			imageStorageDir.mkdirs();
		}

		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		if (takePictureIntent.resolveActivity((slaaskManager.getActivity())
				.getPackageManager()) != null) {
			// Create the File where the photo should go
			File photoFile =  new File(imageStorageDir + File.separator + "IMG_" + String.valueOf(System.currentTimeMillis()) + ".jpg");
			takePictureIntent.putExtra("PhotoPath", mCameraPhotoPath);
			// Continue only if the File was successfully created
			if (photoFile != null) {
				mCameraPhotoPath = "file:"
						+ photoFile.getAbsolutePath();
				takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
						Uri.fromFile(photoFile));
			} else {
				takePictureIntent = null;
			}
		}
		Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
		contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
		contentSelectionIntent.setType("*/*");
		Intent[] intentArray;
		if (takePictureIntent != null) {
			intentArray = new Intent[]{takePictureIntent};
		} else {
			intentArray = new Intent[0];
		}
		Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
		chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
		chooserIntent.putExtra(Intent.EXTRA_TITLE, "Choose image or file");
		chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
		(slaaskManager.getActivity()).startActivityForResult(chooserIntent,
				INPUT_FILE_REQUEST_CODE);

		return true;
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Uri[] results = null;

			if (resultCode == RESULT_OK) {
				if (data == null || data.getData() == null) {

					if (mCameraPhotoPath != null) {
						results = new Uri[] {
								Uri.parse(mCameraPhotoPath)};
					}
				} else {
					String dataString = data.getDataString();
					if (dataString != null) {
						results = new Uri[]{Uri.parse(dataString)};
					}
				}
			}
			mFilePathCallback.onReceiveValue(results);
			mFilePathCallback = null;
		} else {

			if (mUploadMessage == null) {
				return;
			}
			Uri result = null;
			try {
				if (resultCode != RESULT_OK) {
					result = null;
				} else {
					result = data == null ? mCapturedImageURI
							: data.getData();
				}
			} catch (Exception e) {

			}
			mUploadMessage.onReceiveValue(result);
			mUploadMessage = null;
		}
	}

//
//	public void openFileChooser(ValueCallback<Uri> uploadMsg){
//		System.out.println("1 method = ");
//		openFileChooser(uploadMsg, "");
//	}
//
//	public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
//		System.out.println("2 method = ");
//
//		openFileChooser(uploadMsg, acceptType);
//	}
//
//
	private void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {
		mUploadMessage = uploadMsg;

		File imageStorageDir = new File(
				Environment.getExternalStoragePublicDirectory(
						Environment.DIRECTORY_PICTURES)
				, "SLAASK Folder");
		if (!imageStorageDir.exists()) {
			imageStorageDir.mkdirs();
		}

		File file = new File(
				imageStorageDir + File.separator + "IMG_"
						+ String.valueOf(System.currentTimeMillis())
						+ ".jpg");
		mCapturedImageURI = Uri.fromFile(file);
		// Camera capture image intent
		final Intent captureIntent = new Intent(
				android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
		captureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
				mCapturedImageURI);
		Intent i = new Intent(Intent.ACTION_GET_CONTENT);
		i.addCategory(Intent.CATEGORY_OPENABLE);
		i.setType("image/*");

		Intent chooserIntent = Intent.createChooser(i, "Image Chooser");

		chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS,
				new Parcelable[]{captureIntent});

		(slaaskManager.getActivity()).startActivityForResult(chooserIntent,
				INPUT_FILE_REQUEST_CODE);
	}
}
