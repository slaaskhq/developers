package com.slaask.lib.controller.clients;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.slaask.lib.controller.SLAASKManager;

public class WebClient extends WebViewClient {
	private ProgressDialog dialog;

	private SLAASKManager slaaskManager;

	public WebClient(SLAASKManager slaaskManager) {
		this.slaaskManager = slaaskManager;

	}

	@Override
	public void onPageStarted(WebView view, String url, Bitmap favicon) {
		super.onPageStarted(view, url, favicon);
		dialog = ProgressDialog.show(slaaskManager.getActivity(), null, "Loading...");
		dialog.setCancelable(true);
	}

	@Override
	public boolean shouldOverrideUrlLoading(WebView view, String  request) {

		System.out.println("view.getUrl() = " + view.getUrl());
		if (request.contains("closeButtonPressed")) {
			SLAASKManager.getInstance().dismiss();
			return true;
		}
		if (view.getUrl().startsWith("http://") || view.getUrl().startsWith("https://")) {
			Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(view.getUrl()));
			slaaskManager.onBrowserIntent(browserIntent);
			return true;
		}
		return false;
	}

	@Override
	public void onPageFinished(WebView view, String url) {
		super.onPageFinished(view, url);

		if (dialog.isShowing()) {
			dialog.dismiss();
		}
	}
}
